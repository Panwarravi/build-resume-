import React, { useRef, useState } from "react";
import { useReactToPrint } from "react-to-print";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";

export default function ResumeBuilder() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    summary: "",
    experience: "",
    education: ""
  });

  const componentRef = useRef();
  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle: `${formData.name || "Resume"} - CBResume`,
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="max-w-3xl mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4 text-center">📝 Resume Builder</h1>
      <Card className="mb-4">
        <CardContent className="grid gap-4 p-4">
          <Input name="name" placeholder="Full Name" onChange={handleChange} />
          <Input name="email" placeholder="Email" onChange={handleChange} />
          <Input name="phone" placeholder="Phone Number" onChange={handleChange} />
          <Textarea name="summary" placeholder="Professional Summary" onChange={handleChange} />
          <Textarea name="experience" placeholder="Work Experience" onChange={handleChange} />
          <Textarea name="education" placeholder="Education" onChange={handleChange} />
        </CardContent>
      </Card>
      <Button className="w-full" onClick={handlePrint}>📄 Download PDF</Button>

      <div className="mt-8 border-t pt-4">
        <h2 className="text-xl font-semibold mb-2">Preview:</h2>
        <div ref={componentRef} className="bg-white shadow p-4 rounded-md space-y-2">
          <h3 className="text-lg font-bold">{formData.name}</h3>
          <p>{formData.email} | {formData.phone}</p>
          <p className="italic">{formData.summary}</p>
          <div>
            <h4 className="font-semibold">Experience</h4>
            <p>{formData.experience}</p>
          </div>
          <div>
            <h4 className="font-semibold">Education</h4>
            <p>{formData.education}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
